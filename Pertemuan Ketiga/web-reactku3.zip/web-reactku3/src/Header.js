import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <div>
                <h3>Ini adalah komponen Header</h3>
            </div>
        );
    }
} export default Header;